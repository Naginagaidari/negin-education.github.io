const slides=[
"https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1800&q=80",
"https://images.unsplash.com/photo-1509099836639-18ba1795216d?auto=format&fit=crop&w=1800&q=80",
"https://images.unsplash.com/photo-1542810634-71277d95dcbb?auto=format&fit=crop&w=1800&q=80",
"https://images.unsplash.com/photo-1504159506876-f8338247a14a?auto=format&fit=crop&w=1800&q=80"
];
const slidesEl=document.getElementById("slides"),dots=document.getElementById("dots");
slides.forEach((src,i)=>{const s=document.createElement("div");s.className="hero-slide"+(i===0?" active":"");s.style.backgroundImage=`url("${src}")`;slidesEl.appendChild(s);const d=document.createElement("button");d.className=i===0?"active":"";d.setAttribute("aria-label",`اسلاید ${i+1}`);d.onclick=()=>showSlide(i);dots.appendChild(d)});
let current=0;
function showSlide(i){const ss=document.querySelectorAll(".hero-slide"),ds=dots.children;ss[current].classList.remove("active");ds[current].classList.remove("active");current=i%ss.length;ss[current].classList.add("active");ds[current].classList.add("active")}
setInterval(()=>showSlide(current+1),5000);

document.querySelectorAll("[data-target]").forEach(b=>b.onclick=()=>document.querySelector(b.dataset.target)?.scrollIntoView({behavior:"smooth"}));
document.getElementById("menuBtn").onclick=()=>document.getElementById("mobileNav").classList.toggle("open");

const translations={
fa:{brandSmall:"مؤسسه‌ی خدماتی و حرفوی زنان بی‌بضاعت",brand:"مرکز آموزشی و توانبخشی نگین",about:"درباره ما",services:"خدمات",education:"آموزش",games:"هنر و بازی",register:"ثبت‌نام",contact:"تماس",rehab:"توانبخشی",eyebrow:"آموزش • توانبخشی • حمایت",heroTitle:"مرکز آموزشی و توانبخشی نگین",heroText:"خانه‌ای امن برای آموزش و توانمندسازی کودکان دارای معلولیت در افغانستان",slogan:"هر کودک یک نگین است",viewServices:"مشاهده خدمات",aboutHeading:"هر کودک شایسته فرصت برابر است"},
ps:{brandSmall:"د بې وزلو ښځو د خدماتو او حرفوي چارو مؤسسه",brand:"د نگین د ښوونې او بیارغونې مرکز",about:"زموږ په اړه",services:"خدمتونه",education:"ښوونه",games:"هنر او لوبې",register:"نوم‌لیکنه",contact:"اړیکه",rehab:"بیارغونه",eyebrow:"ښوونه • بیارغونه • ملاتړ",heroTitle:"د نگین د ښوونې او بیارغونې مرکز",heroText:"په افغانستان کې د معلولیت لرونکو ماشومانو لپاره د ښوونې او پیاوړتیا خوندي کور",slogan:"هر ماشوم یو نگین دی",viewServices:"خدمتونه وګورئ",aboutHeading:"هر ماشوم د برابر فرصت وړ دی"}
};
let lang="fa";
function setLanguage(l){lang=l;document.documentElement.lang=l==="ps"?"ps":"fa";document.documentElement.dir="rtl";document.querySelectorAll("[data-i18n]").forEach(el=>{const k=el.dataset.i18n;if(translations[l][k])el.textContent=translations[l][k]});document.getElementById("langBtn").title=l==="fa"?"پشتو":"دری";localStorage.lang=l}
document.getElementById("langBtn").onclick=()=>setLanguage(lang==="fa"?"ps":"fa");setLanguage(localStorage.lang||"fa");

const modal=document.getElementById("accessModal");
document.getElementById("accessBtn").onclick=()=>{modal.classList.add("open");modal.setAttribute("aria-hidden","false")};
document.getElementById("accessClose").onclick=()=>modal.classList.remove("open");
document.getElementById("fontDown").onclick=()=>document.body.classList.add("font-large");
document.getElementById("fontUp").onclick=()=>{document.body.classList.remove("font-large");document.body.classList.add("font-xl")};
document.getElementById("fontReset").onclick=()=>document.body.classList.remove("font-large","font-xl");
document.getElementById("darkBtn").onclick=()=>document.body.classList.toggle("dark");
document.getElementById("contrastBtn").onclick=()=>document.body.classList.toggle("high-contrast");
document.getElementById("resetAccess").onclick=()=>document.body.classList.remove("dark","high-contrast","font-large","font-xl");

document.querySelectorAll(".speak").forEach(b=>b.onclick=()=>{const el=document.querySelector(b.dataset.speak);if(!el)return;const text=el.innerText.replace(/🔊/g," ");speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang=lang==="ps"?"ps-AF":"fa-AF";u.rate=.88;speechSynthesis.speak(u)});

const canvas=document.getElementById("canvas"),ctx=canvas.getContext("2d");let drawing=false,last=null;
function pos(e){const r=canvas.getBoundingClientRect(),p=e.touches?.[0]||e;return{x:(p.clientX-r.left)*canvas.width/r.width,y:(p.clientY-r.top)*canvas.height/r.height}}
function draw(e){if(!drawing)return;const p=pos(e);ctx.beginPath();ctx.moveTo(last.x,last.y);ctx.lineTo(p.x,p.y);ctx.lineWidth=+document.getElementById("brush").value;ctx.lineCap="round";ctx.stroke();last=p;e.preventDefault()}
canvas.addEventListener("pointerdown",e=>{drawing=true;last=pos(e)});canvas.addEventListener("pointermove",draw);window.addEventListener("pointerup",()=>drawing=false);
document.getElementById("clearCanvas").onclick=()=>ctx.clearRect(0,0,canvas.width,canvas.height);

const nums=document.getElementById("numbers"),targetEl=document.getElementById("numberTarget"),msg=document.getElementById("gameMessage");
function newNumberGame(){const target=Math.floor(Math.random()*9)+1;targetEl.textContent=target;nums.innerHTML="";for(let i=1;i<=9;i++){const b=document.createElement("button");b.textContent=i;b.onclick=()=>{msg.textContent=i===target?"آفرین! درست پیدا کردی.":"دوباره تلاش کن.";if(i===target)setTimeout(newNumberGame,700)};nums.appendChild(b)}}newNumberGame();

const letters=[["آ","آب"],["ب","باد"],["پ","پرنده"],["ت","توپ"],["ج","جاده"],["د","درخت"],["ر","رود"],["س","ستاره"]];let li=0;
document.getElementById("nextLetter").onclick=()=>{li=(li+1)%letters.length;document.getElementById("letter").textContent=letters[li][0];document.getElementById("letterMeaning").textContent=`${letters[li][0]} مثل ${letters[li][1]}`};

const piano=document.getElementById("piano");[261.63,293.66,329.63,349.23,392,440,493.88].forEach((freq,i)=>{const b=document.createElement("button");b.textContent=["دو","ر","می","فا","سل","لا","سی"][i];b.onclick=()=>tone(freq);piano.appendChild(b)});
function tone(freq){const A=new AudioContext(),o=A.createOscillator(),g=A.createGain();o.frequency.value=freq;o.connect(g);g.connect(A.destination);g.gain.setValueAtTime(.18,A.currentTime);g.gain.exponentialRampToValueAtTime(.001,A.currentTime+.45);o.start();o.stop(A.currentTime+.45)}

document.getElementById("regForm").onsubmit=e=>{e.preventDefault();document.getElementById("formStatus").textContent="درخواست شما در این نسخه نمایشی ثبت شد. برای ارسال واقعی، فرم را به یک سرویس فرم یا بک‌اند متصل کنید.";e.target.reset()};

const chat=document.getElementById("chat"),body=document.getElementById("chatBody");
document.getElementById("chatFab").onclick=()=>{chat.classList.toggle("open");chat.setAttribute("aria-hidden",String(!chat.classList.contains("open")))};
document.getElementById("chatClose").onclick=()=>chat.classList.remove("open");
function botAnswer(q){q=q.toLowerCase();if(q.includes("ثبت")||q.includes("نام"))return"برای ثبت‌نام، به بخش «ثبت‌نام» بروید و نام کودک، سرپرست، شماره تماس و خدمت مورد نیاز را وارد کنید.";if(q.includes("تماس")||q.includes("شماره"))return"شماره تماس مرکز: ۰۷۸۶۸۳۸۰۰۲ و ایمیل: negineducationcenter@gmail.com است.";if(q.includes("آدرس")||q.includes("کابل"))return"مرکز در سرک ۳۷، پروژه وزیر آباد، کابل، افغانستان قرار دارد.";if(q.includes("فیزی")||q.includes("کاردرمانی")||q.includes("گفتار"))return"نگین خدمات فیزیوتراپی، کاردرمانی و گفتاردرمانی را معرفی و ارائه می‌کند؛ نیاز هر کودک باید توسط متخصص ارزیابی شود.";if(q.includes("ساعت"))return"شنبه تا چهارشنبه از ۸ صبح تا ۴ بعدازظهر و پنجشنبه از ۸ صبح تا ۱۲ ظهر.";return"من در این نسخه اطلاعات صفحات وب‌سایت نگین را پاسخ می‌دهم. درباره ثبت‌نام، خدمات، تماس، آدرس یا ساعات کاری بپرسید."}
function sendChat(){const inp=document.getElementById("chatInput"),q=inp.value.trim();if(!q)return;body.innerHTML+=`<div class="user">${q}</div><div class="bot">${botAnswer(q)}</div>`;inp.value="";body.scrollTop=body.scrollHeight}
document.getElementById("chatSend").onclick=sendChat;document.getElementById("chatInput").onkeydown=e=>{if(e.key==="Enter")sendChat()};
